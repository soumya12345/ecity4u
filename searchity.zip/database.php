<?php
session_start();
$host='localhost';
$user='root';
$pass='colourfade';
$db='seacrhcity';
$sql=mysql_connect($host,$user,$pass) or die('database not connected'.mysql_error());
mysql_select_db($db,$sql) or die('database not selected'.mysql_error());

function gettotalproduct($catid,$subcat,$subtype)
{
    $qwery=mysql_query("select * from `product` where `category` like '%$catid,%' and `chcategory` like '%$subcat,%' and `chtype` like '%$subtype,%'")or die(mysql_error());
    return mysql_num_rows($qwery);
}
?>
