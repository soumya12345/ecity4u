<?php
include_once('database.php');
$cat=$_GET['catid'];
$subid=$_GET['subid'];
$subtype=$_GET['subtype'];
$qwery=mysql_query("select `icon`  from `category` where `id`='$cat'")or die(mysql_error());
$resicon=mysql_fetch_array($qwery);
$mapicon='head-searchcity/'.$resicon['icon'];

$sql="select * from `product` where `category` like '%$cat,%' and `chcategory` like '%$subid,%' and `chtype` like '%$subtype,%'";
$query = mysql_query($sql);
?>

 <style>
		  .content p:nth-child(even){color:#999; font-family:Georgia,serif; font-size:17px; font-style:italic;}
		.content p:nth-child(3n+0){color:#c96;}
		.content .content{width:100%; margin:0px; background:#252525; -moz-box-sizing:border-box; -webkit-box-sizing:border-box; box-sizing:border-box;}
		.content .content .content{background:#191919;}
		#content-2{overflow:hidden; height:auto; padding:0px;}
		#content-2 p{float:left; width:300px; min-width:100px; margin-right:0px; background:rgba(0,0,0,0.3); padding:0px; -webkit-border-radius:3px; -moz-border-radius:3px; border-radius:3px;}
		#content-2 p:last-child{width:auto; margin-right:0;}
		</style>
<ul id="content-2" class="content" style="background: #efefef; border: none;">
    <?php
    $i=0;
while($res_map=mysql_fetch_array($query))
{
    ?>

	<li class="lasti" style="float: left;padding: 10px; max-width:130px; list-style-type:none;" lastid="<?php echo $i;?>" mapicon="<?php echo $mapicon;?>"><a href="#" onclick="return getmapindividual(<?php echo $res_map['id'];?>,<?php echo $cat;?>);"><img src="head-searchcity/<?php echo $res_map['image'];?>" alt="image01" width="100" height="100" style="border-radius:8px; border:2px solid #fff;-webkit-box-shadow: 0 8px 6px -6px black; -moz-box-shadow: 0 8px 6px -6px black;
	        box-shadow: 0 8px 6px -6px black; outline: none;"/><br/><?php echo $res_map['productname'];?></a></li>
<?php
$i++;
}
?>
</ul>



<script src="jquery.mCustomScrollbar.concat.min.js"></script>
	<script>
		
			$(function(){
				$("#content-2").mCustomScrollbar({
					horizontalScroll:true,
					callbacks:{
						onScroll:function(){ 
							$("."+this.attr("id")+"-pos").text(mcs.left);
							alert(23);
						}
					}
				});
				/*demo fn*/
				
				$(".output a[rel~='_mCS_2_scrollTo']").click(function(e){
					e.preventDefault();
					$("#content-1").mCustomScrollbar("scrollTo","#content-2");
					$("#content-2").mCustomScrollbar("scrollTo",$(this).attr("href"));
				});
			});
		
	</script>