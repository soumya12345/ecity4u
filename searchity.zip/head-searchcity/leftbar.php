<div id="left_box">
						<div class="list_menu">
								 <ul>
										<li class="active">
											<i class="icon-chevron-right"></i> Dashboard</li>
										<li>
											<a href="profession.php"><i class="icon-chevron-right"><img src="img/1.png" /></i>Add Profession</a>
										</li>
										<li>
											<a href="category.php"><i class="icon-chevron-right"><img src="img/1.png" /></i>Category</a>
										</li>
										<li>
											<a href="subcategory.php"><i class="icon-chevron-right"><img src="img/1.png" /></i>Sub-Category</a>
										</li>
										<li>
											<a href="subsubcategory.php"><i class="icon-chevron-right"><img src="img/1.png" /></i>Sub-Sub-Category</a>
										</li>
										<li>
											<a href="subchcategory.php"><i class="icon-chevron-right"><img src="img/1.png" /></i>Sub-Child-Category</a>
										</li>
										<li>
											<a href="product.php"><i class="icon-chevron-right"><img src="img/1.png" /></i>Add Location</a>
										</li>
										<li>
											<a href="addbusstop.php"><i class="icon-chevron-right"><img src="img/1.png" /></i>Add Bus Stoppage</a>
										</li>
										<li>
											<a href="busroutemap.php"><i class="icon-chevron-right"><img src="img/1.png" /></i>Bus Route Map</a>
										</li>
										<li>
											<a href="logout.php"><i class="icon-chevron-right"><img src="img/1.png" /></i>LOGOUT</a>
										</li>
						  		</ul>
						</div>
				</div>